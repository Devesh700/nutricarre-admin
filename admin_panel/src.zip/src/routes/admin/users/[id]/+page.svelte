<script>
  import { supabase } from '$lib/supabase';
  import { invalidateAll } from '$app/navigation';
  import { deserialize } from '$app/forms';

  let { data } = $props();
  let profile = $derived(data.profile);
  let calorieLogs = $derived(data.calorieLogs);
  let hydrationLogs = $derived(data.hydrationLogs);
  let plans = $derived(data.plans);
  let loading = $state(false);
  let showAssignModal = $state(false);

  async function assignPlan(planId) {
    loading = true;
    try {
      await supabase
        .from('profiles')
        .update({ active_plan_id: planId })
        .eq('id', profile.id);
      showAssignModal = false;
      await invalidateAll();
    } catch (err) {
      alert('Error: ' + err.message);
    } finally {
      loading = false;
    }
  }

  function calculateBMI(weight, height) {
    if (!weight || !height) return 0;
    const heightInMeters = height / 100;
    return (weight / (heightInMeters * heightInMeters)).toFixed(1);
  }

  async function toggleUserStatus() {
    loading = true;
    const formData = new FormData();
    formData.append('userId', profile.id);
    formData.append('isActive', !(profile.is_active !== false));

    const response = await fetch('?/toggleActive', {
      method: 'POST',
      body: formData
    });

    const result = deserialize(await response.text());
    if (result.type === 'success') {
      await invalidateAll();
    } else {
      alert('Error updating status: ' + (result.data?.message || 'Unknown error'));
    }
    loading = false;
  }

  async function removeUser() {
    if (!confirm('Are you sure you want to permanently delete this user? This cannot be undone.')) return;
    
    loading = true;
    const formData = new FormData();
    formData.append('userId', profile.id);

    const response = await fetch('?/deleteUser', {
      method: 'POST',
      body: formData
    });

    if (response.redirected) {
      window.location.href = response.url;
    } else {
      const result = deserialize(await response.text());
      alert('Error removing user: ' + (result.data?.message || 'Unknown error'));
    }
    loading = false;
  }

  const bmi = $derived(calculateBMI(profile.current_weight, profile.height));
  const bmiStatus = $derived(bmi < 18.5 ? 'UNDER' : bmi < 25 ? 'HEALTHY' : bmi < 30 ? 'OVER' : 'OBESE');
</script>

<div class="user-detail">
  <!-- Top Navigation & Actions -->
  <div class="page-header">
    <a href="/admin/users" class="btn-back">
      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      Back to Users
    </a>
    
    <div class="actions">
      <button 
        class="status-pill {profile.is_active !== false ? 'active' : 'inactive'}"
        onclick={toggleUserStatus}
        disabled={loading}
      >
        <span class="dot"></span>
        {profile.is_active !== false ? 'Account Active' : 'Account Inactive'}
      </button>
      
      <button class="btn-danger-outline" onclick={removeUser} disabled={loading}>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
        Delete User
      </button>
    </div>
  </div>

  <!-- User Identity -->
  <div class="profile-hero">
    <div class="avatar">
      {profile.full_name?.[0] || profile.email[0].toUpperCase()}
    </div>
    <div class="identity">
      <h1>{profile.full_name || 'Unnamed User'}</h1>
      <p class="email">{profile.email}</p>
      <div class="meta-pills">
        <span class="pill">ID: {profile.id.slice(0, 8)}...</span>
        <span class="pill">Joined {new Date(profile.joined_at).toLocaleDateString()}</span>
      </div>
    </div>
  </div>

  <!-- Quick Stats -->
  <div class="stats-row">
    <div class="stat-card">
      <div class="s-icon" style="background: #EFF6FF; color: #3B82F6">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>
      </div>
      <div class="s-data">
        <span class="s-label">Weight</span>
        <span class="s-value">{profile.current_weight || '0'} kg</span>
        <span class="s-sub">Target: {profile.target_weight || '0'} kg</span>
      </div>
    </div>

    <div class="stat-card">
      <div class="s-icon" style="background: #ECFDF5; color: #10B981">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"></path></svg>
      </div>
      <div class="s-data">
        <span class="s-label">BMI Score</span>
        <span class="s-value">{bmi}</span>
        <span class="badge {bmiStatus.toLowerCase()}">{bmiStatus}</span>
      </div>
    </div>

    <div class="stat-card">
      <div class="s-icon" style="background: #FFFBEB; color: #F59E0B">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20m10-10H2"></path></svg>
      </div>
      <div class="s-data">
        <span class="s-label">Height & Age</span>
        <span class="s-value">{profile.height || '-'} cm</span>
        <span class="s-sub">{profile.age || '-'} years old</span>
      </div>
    </div>

    <div class="stat-card">
      <div class="s-icon" style="background: #F5F3FF; color: #8B5CF6">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
      </div>
      <div class="s-data">
        <span class="s-label">Diet Plan</span>
        <span class="s-value">{profile.is_subscribed ? 'PREMIUM' : 'FREE'}</span>
        <button class="btn-text-accent" onclick={() => showAssignModal = true}>Change Plan</button>
      </div>
    </div>
  </div>

  <!-- Main Grid -->
  <div class="main-grid">
    <!-- Left: Detailed Info -->
    <div class="details-column">
      <div class="card">
        <div class="card-header">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><polyline points="17 11 19 13 23 9"></polyline></svg>
          <h3>Profile & Preferences</h3>
        </div>
        <div class="info-list">
          <div class="info-item">
            <label>Phone Number</label>
            <span>{profile.phone || 'Not provided'}</span>
          </div>
          <div class="info-item">
            <label>Dietary Preference</label>
            <span>{profile.dietary_preference || 'General'}</span>
          </div>
          <div class="info-item">
            <label>Activity Level</label>
            <span>{profile.activity_level || 'Moderate'}</span>
          </div>
          <div class="info-item">
            <label>Health Goal</label>
            <span>{profile.health_goal || 'Stay Healthy'}</span>
          </div>
          <div class="info-item full">
            <label>Medical History</label>
            <p>{profile.medical_history || 'No medical history reported.'}</p>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v10l4.5 4.5"></path><circle cx="12" cy="12" r="10"></circle></svg>
          <h3>Lifestyle Routine</h3>
        </div>
        <div class="info-list">
          <div class="info-item">
            <label>Sleep Cycle</label>
            <span>{profile.wake_time || '07:00'} - {profile.sleep_time || '22:00'}</span>
          </div>
          <div class="info-item">
            <label>Breakfast</label>
            <span>{profile.breakfast_routine || 'None'}</span>
          </div>
          <div class="info-item">
            <label>Lunch</label>
            <span>{profile.lunch_routine || 'None'}</span>
          </div>
          <div class="info-item">
            <label>Dinner</label>
            <span>{profile.dinner_routine || 'None'}</span>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
          <h3>Location Details</h3>
        </div>
        <div class="info-list">
          <div class="info-item full">
            <label>Street Address</label>
            <span>{profile.street_address || 'Not set'}</span>
          </div>
          <div class="info-item">
            <label>City</label>
            <span>{profile.city || 'Not set'}</span>
          </div>
          <div class="info-item">
            <label>Zip Code</label>
            <span>{profile.zip_code || 'Not set'}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Right: Activity Logs -->
    <div class="logs-column">
      <div class="card log-card">
        <div class="card-header">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
          <h3>Recent Calorie Logs</h3>
        </div>
        <div class="log-list">
          {#each calorieLogs as log}
            <div class="log-item">
              <div class="log-meta">
                <span class="title">{log.food_name}</span>
                <span class="time">{new Date(log.logged_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
              </div>
              <span class="log-val">{log.calories} <small>kcal</small></span>
            </div>
          {:else}
            <div class="empty">No entries found</div>
          {/each}
        </div>
      </div>

      <div class="card log-card">
        <div class="card-header">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path></svg>
          <h3>Recent Hydration Logs</h3>
        </div>
        <div class="log-list">
          {#each hydrationLogs as log}
            <div class="log-item">
              <div class="log-meta">
                <span class="title">Water Intake</span>
                <span class="time">{new Date(log.logged_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
              </div>
              <span class="log-val water">{log.amount_ml} <small>ml</small></span>
            </div>
          {:else}
            <div class="empty">No entries found</div>
          {/each}
        </div>
      </div>
    </div>
  </div>
</div>

{#if showAssignModal}
  <div class="modal-overlay" onclick={() => showAssignModal = false}>
    <div class="modal" onclick={e => e.stopPropagation()}>
      <div class="modal-header">
        <h3>Assign Clinical Plan</h3>
        <button class="close" onclick={() => showAssignModal = false}>&times;</button>
      </div>
      <div class="modal-body">
        <p class="modal-sub">Select a new health plan for <strong>{profile.full_name || profile.email}</strong></p>
        <div class="plan-options">
          <button 
            class="plan-item" class:selected={profile.active_plan_id === null}
            onclick={() => assignPlan(null)}
            disabled={loading}
          >
            <div class="plan-info">
              <span class="p-name">None (Remove Plan)</span>
              <span class="p-desc">User will be on the free general tier.</span>
            </div>
            {#if profile.active_plan_id === null}<span class="check">✓</span>{/if}
          </button>
          {#each plans as plan}
            <button 
              class="plan-item" class:selected={profile.active_plan_id === plan.id}
              onclick={() => assignPlan(plan.id)}
              disabled={loading}
            >
              <div class="plan-info">
                <span class="p-name">{plan.name}</span>
                <span class="p-desc">₹{plan.price}/month - {plan.duration_months} months</span>
              </div>
              {#if profile.active_plan_id === plan.id}<span class="check">✓</span>{/if}
            </button>
          {/each}
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn-outline full" onclick={() => showAssignModal = false}>Cancel</button>
      </div>
    </div>
  </div>
{/if}

<style>
  .user-detail {
    animation: fadeIn 0.3s ease;
  }

  /* Header */
  .page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
  }
  .btn-back {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--text-muted);
    text-decoration: none;
    font-weight: 700;
    font-size: 0.8125rem;
    transition: color 0.2s;
  }
  .btn-back:hover { color: var(--primary-accent); }
  
  .actions { display: flex; gap: 0.75rem; }
  
  .status-pill {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 1rem;
    border-radius: 99px;
    font-size: 0.75rem;
    font-weight: 700;
    border: 1px solid var(--border);
    background: var(--surface);
    cursor: pointer;
    transition: all 0.2s;
  }
  .status-pill.active { color: #10B981; border-color: #D1FAE5; background: #ECFDF5; }
  .status-pill.inactive { color: #EF4444; border-color: #FEE2E2; background: #FEF2F2; }
  .status-pill .dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
  
  .btn-danger-outline {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 1rem;
    border-radius: 99px;
    font-size: 0.75rem;
    font-weight: 700;
    border: 1px solid #FEE2E2;
    background: var(--surface);
    color: #EF4444;
    cursor: pointer;
    transition: all 0.2s;
  }
  .btn-danger-outline:hover { background: #FEF2F2; }

  /* Hero */
  .profile-hero {
    display: flex;
    align-items: center;
    gap: 1.5rem;
    margin-bottom: 2.5rem;
    padding: 1.5rem;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-sm);
  }
  .avatar {
    width: 72px; height: 72px;
    background: linear-gradient(135deg, var(--primary-accent), #818CF8);
    color: white;
    border-radius: 1.25rem;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.75rem;
    font-weight: 800;
  }
  .identity h1 { font-size: 1.5rem; font-weight: 800; color: var(--text); margin-bottom: 0.25rem; }
  .identity .email { color: var(--text-muted); font-size: 0.875rem; margin-bottom: 0.75rem; }
  .meta-pills { display: flex; gap: 0.5rem; }
  .pill { font-size: 0.6875rem; font-weight: 700; color: var(--text-muted); background: var(--bg); padding: 0.25rem 0.625rem; border-radius: 6px; }

  /* Stats */
  .stats-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
    margin-bottom: 2rem;
  }
  .stat-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 1.25rem;
    display: flex;
    gap: 1rem;
    align-items: center;
    box-shadow: var(--shadow-sm);
  }
  .s-icon { width: 42px; height: 42px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .s-data { display: flex; flex-direction: column; }
  .s-label { font-size: 0.6875rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.04em; }
  .s-value { font-size: 1.125rem; font-weight: 800; color: var(--text); }
  .s-sub { font-size: 0.75rem; color: var(--text-muted); font-weight: 600; }
  
  .badge { align-self: flex-start; padding: 2px 8px; border-radius: 4px; font-size: 0.625rem; font-weight: 800; margin-top: 2px; }
  .badge.healthy { background: #DCFCE7; color: #166534; }
  .badge.over, .badge.obese { background: #FEF2F2; color: #991B1B; }
  .badge.under { background: #FFFBEB; color: #92400E; }

  /* Grid Layout */
  .main-grid {
    display: grid;
    grid-template-columns: 1.8fr 1fr;
    gap: 1.5rem;
  }
  
  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 1.5rem;
    box-shadow: var(--shadow-sm);
    margin-bottom: 1.5rem;
  }
  .card-header { display: flex; align-items: center; gap: 0.75rem; margin-bottom: 1.5rem; color: var(--text); }
  .card-header h3 { font-size: 0.9375rem; font-weight: 800; }
  .card-header svg { color: var(--primary-accent); }

  .info-list { display: grid; grid-template-columns: 1fr 1fr; gap: 1.25rem; }
  .info-item { display: flex; flex-direction: column; gap: 0.25rem; }
  .info-item.full { grid-column: span 2; }
  .info-item label { font-size: 0.6875rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.04em; }
  .info-item span, .info-item p { font-size: 0.875rem; font-weight: 600; color: var(--text-secondary); }
  .info-item p { line-height: 1.6; }

  /* Logs */
  .log-list { display: flex; flex-direction: column; gap: 0.5rem; }
  .log-item { display: flex; justify-content: space-between; align-items: center; padding: 0.75rem 1rem; background: var(--bg); border-radius: 12px; }
  .log-meta { display: flex; flex-direction: column; }
  .log-meta .title { font-size: 0.8125rem; font-weight: 700; color: var(--text); }
  .log-meta .time { font-size: 0.6875rem; color: var(--text-muted); }
  .log-val { font-size: 0.9375rem; font-weight: 800; color: var(--primary-accent); }
  .log-val.water { color: #3B82F6; }
  .log-val small { font-size: 0.6875rem; font-weight: 600; }

  .empty { text-align: center; padding: 2rem 0; color: var(--text-muted); font-size: 0.8125rem; font-style: italic; }

  .btn-text-accent {
    background: none; border: none; padding: 0;
    color: var(--primary-accent); font-size: 0.75rem; font-weight: 700;
    cursor: pointer; text-align: left; margin-top: 2px;
  }
  .btn-text-accent:hover { text-decoration: underline; }

  /* Modal */
  .modal-overlay {
    position: fixed; inset: 0; background: rgba(15, 23, 42, 0.4);
    backdrop-filter: blur(6px); z-index: 1000;
    display: flex; align-items: center; justify-content: center; padding: 1.5rem;
  }
  .modal {
    background: var(--surface); border-radius: var(--radius-lg); width: 100%; max-width: 480px;
    box-shadow: var(--shadow-lg); animation: fadeIn 0.2s ease;
  }
  .modal-header { padding: 1.25rem 1.5rem; border-bottom: 1px solid var(--border-light); display: flex; justify-content: space-between; align-items: center; }
  .modal-header h3 { font-size: 1rem; font-weight: 800; }
  .close { background: none; border: none; font-size: 1.5rem; color: var(--text-muted); cursor: pointer; }
  
  .modal-body { padding: 1.5rem; }
  .modal-sub { font-size: 0.875rem; color: var(--text-muted); margin-bottom: 1.5rem; }
  
  .plan-options { display: flex; flex-direction: column; gap: 0.75rem; }
  .plan-item {
    display: flex; justify-content: space-between; align-items: center;
    padding: 1rem 1.25rem; border-radius: var(--radius); border: 1.5px solid var(--border);
    background: var(--surface); cursor: pointer; transition: all 0.2s;
    text-align: left;
  }
  .plan-item:hover { border-color: var(--primary-accent); background: var(--bg); }
  .plan-item.selected { border-color: var(--primary-accent); background: var(--primary-accent-light); }
  
  .plan-info { display: flex; flex-direction: column; gap: 0.125rem; }
  .p-name { font-weight: 700; font-size: 0.875rem; color: var(--text); }
  .p-desc { font-size: 0.75rem; color: var(--text-muted); font-weight: 500; }
  .check { color: var(--primary-accent); font-weight: 900; }

  .modal-footer { padding: 1rem 1.5rem; background: var(--bg); border-top: 1px solid var(--border-light); border-radius: 0 0 var(--radius-lg) var(--radius-lg); }
  .btn-outline.full { width: 100%; padding: 0.625rem; border: 1.5px solid var(--border); background: var(--surface); border-radius: var(--radius); font-weight: 600; font-size: 0.8125rem; cursor: pointer; }

  @media (max-width: 1100px) {
    .stats-row { grid-template-columns: repeat(2, 1fr); }
    .main-grid { grid-template-columns: 1fr; }
  }
</style>
