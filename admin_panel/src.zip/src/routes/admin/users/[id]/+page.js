import { supabase } from '$lib/supabase';
import { error } from '@sveltejs/kit';

export async function load({ params }) {
    const { id } = params;

    const [userResponse, caloriesResponse, hydrationResponse, plansResponse] = await Promise.all([
        supabase
            .from('profiles')
            .select('*, diet_plans:active_plan_id(name)')
            .eq('id', id)
            .single(),
        supabase
            .from('calorie_logs')
            .select('*')
            .eq('user_id', id)
            .order('logged_at', { ascending: false })
            .limit(20),
        supabase
            .from('hydration_logs')
            .select('*')
            .eq('user_id', id)
            .order('logged_at', { ascending: false })
            .limit(20),
        supabase
            .from('diet_plans')
            .select('id, name')
    ]);

    if (userResponse.error) {
        throw error(404, 'User not found');
    }

    return {
        profile: userResponse.data,
        calorieLogs: caloriesResponse.data || [],
        hydrationLogs: hydrationResponse.data || [],
        plans: plansResponse.data || []
    };
}
