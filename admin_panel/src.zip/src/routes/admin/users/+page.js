import { supabase } from '$lib/supabase';

export const load = async () => {
  // Try fetching with join first
  const { data: users, error: userError } = await supabase
    .from('profiles')
    .select('*, diet_plans:active_plan_id(name)');

  const { data: plans, error: planError } = await supabase
    .from('diet_plans')
    .select('id, name');

  if (userError) {
    console.error('Error fetching users with join:', userError);
    // Fallback to simple fetch if join fails
    const { data: simpleUsers, error: simpleError } = await supabase
      .from('profiles')
      .select('*');
    
    return {
      users: simpleUsers || [],
      plans: plans || [],
      error: simpleError ? simpleError.message : userError.message
    };
  }

  return {
    users: users || [],
    plans: plans || [],
    error: null
  };
};
