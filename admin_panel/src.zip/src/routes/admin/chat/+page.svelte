<script>
  import { supabase } from '$lib/supabase';
  import { onMount, onDestroy } from 'svelte';

  let loading = $state(true);
  let allMessages = $state([]);
  let uniqueUsers = $state([]);
  let selectedUserId = $state(null);
  let messageText = $state('');
  
  let subscription;

  onMount(async () => {
    await fetchUsersWithMessages();
    setupRealtime();
  });

  onDestroy(() => {
    if (subscription) {
      supabase.removeChannel(subscription);
    }
  });

  async function fetchUsersWithMessages() {
    loading = true;
    try {
      // Fetch recent messages
      const { data: msgs, error } = await supabase
        .from('chat_messages')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      allMessages = msgs || [];

      // Extract unique user ids
      const userIds = [...new Set(allMessages.map(m => m.user_id))];

      let profilesData = [];
      if (userIds.length > 0) {
        const { data: profs, error: profErr } = await supabase
          .from('profiles')
          .select('id, full_name, email')
          .in('id', userIds);
        
        if (!profErr && profs) {
          profilesData = profs;
        }
      }

      // Extract unique users
      const userMap = new Map();
      allMessages.forEach(m => {
        if (!userMap.has(m.user_id)) {
          const profile = profilesData.find(p => p.id === m.user_id) || { full_name: 'Unknown User', email: '' };
          userMap.set(m.user_id, {
            id: m.user_id,
            full_name: profile.full_name || profile.email || 'Unknown User',
            email: profile.email || '',
            lastMessage: m.message,
            time: new Date(m.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
          });
        }
      });
      uniqueUsers = Array.from(userMap.values());
    } catch (err) {
      console.error('Error fetching chats:', err);
    } finally {
      loading = false;
    }
  }

  function setupRealtime() {
    subscription = supabase
      .channel('admin_chat')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages' }, payload => {
        // Fetch again to get profile relations or append locally
        fetchUsersWithMessages();
      })
      .subscribe();
  }

  let selectedUserMessages = $derived(
    allMessages.filter(m => m.user_id === selectedUserId).reverse()
  );

  let selectedUser = $derived(
    uniqueUsers.find(u => u.id === selectedUserId)
  );

  async function sendMessage() {
    if (!messageText.trim() || !selectedUserId) return;

    try {
      const { error } = await supabase.from('chat_messages').insert({
        user_id: selectedUserId,
        sender_type: 'admin',
        message: messageText.trim()
      });

      if (error) throw error;
      messageText = '';
      
      // Realtime will trigger a refresh, but we can optimistically append
      await fetchUsersWithMessages();
    } catch (err) {
      console.error('Error sending message:', err);
      alert('Failed to send message');
    }
  }
</script>

<div class="chat-page">
  <div class="sidebar">
    <div class="header">
      <h2>Support Chats</h2>
      <p>Users needing assistance</p>
    </div>

    <div class="user-list">
      {#if loading}
        <div class="loading">Loading...</div>
      {:else if uniqueUsers.length === 0}
        <div class="empty-state">No active chats</div>
      {:else}
        {#each uniqueUsers as user}
          <div 
            class="user-item {selectedUserId === user.id ? 'active' : ''}"
            onclick={() => selectedUserId = user.id}
          >
            <div class="avatar">{user.full_name[0].toUpperCase()}</div>
            <div class="user-info">
              <div class="top-row">
                <span class="name">{user.full_name}</span>
                <span class="time">{user.time}</span>
              </div>
              <span class="last-msg">{user.lastMessage}</span>
            </div>
          </div>
        {/each}
      {/if}
    </div>
  </div>

  <div class="chat-area">
    {#if selectedUserId}
      <div class="chat-header">
        <div class="avatar">{selectedUser?.full_name[0].toUpperCase()}</div>
        <div>
          <h3>{selectedUser?.full_name}</h3>
          <span class="email">{selectedUser?.email}</span>
        </div>
      </div>

      <div class="messages">
        {#each selectedUserMessages as msg}
          <div class="message {msg.sender_type === 'admin' ? 'admin' : 'user'}">
            <div class="bubble">
              {#if msg.image_url}
                <img src={msg.image_url} alt="Uploaded file" />
              {/if}
              {#if msg.message}
                <p>{msg.message}</p>
              {/if}
            </div>
            <span class="msg-time">{new Date(msg.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
          </div>
        {/each}
      </div>

      <div class="input-area">
        <input 
          type="text" 
          bind:value={messageText} 
          placeholder="Type your reply..." 
          onkeydown={(e) => e.key === 'Enter' && sendMessage()}
        />
        <button onclick={sendMessage} disabled={!messageText.trim()}>Send</button>
      </div>
    {:else}
      <div class="no-selection">
        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
        <h3>Select a conversation</h3>
        <p>Choose a user from the left to start chatting</p>
      </div>
    {/if}
  </div>
</div>

<style>
  .chat-page {
    display: flex;
    height: calc(100vh - 120px);
    background: var(--surface);
    border-radius: var(--radius-lg);
    overflow: hidden;
    border: 1px solid var(--border);
    box-shadow: var(--shadow);
    animation: fadeIn 0.3s ease;
  }

  .sidebar {
    width: 320px;
    border-right: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    background: var(--bg);
  }

  .header {
    padding: 1.5rem;
    border-bottom: 1px solid var(--border);
    background: var(--surface);
  }

  .header h2 {
    font-size: 1.125rem;
    font-weight: 800;
    color: var(--text);
    margin: 0;
  }

  .header p {
    font-size: 0.8125rem;
    color: var(--text-muted);
    margin: 0.25rem 0 0 0;
  }

  .user-list {
    flex: 1;
    overflow-y: auto;
  }

  .user-item {
    display: flex;
    padding: 1rem 1.5rem;
    gap: 1rem;
    cursor: pointer;
    border-bottom: 1px solid var(--border-light);
    transition: all 0.2s;
  }

  .user-item:hover {
    background: var(--border-light);
  }

  .user-item.active {
    background: var(--primary-accent-light);
    border-left: 4px solid var(--primary-accent);
  }

  .avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--primary-accent), #818CF8);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    flex-shrink: 0;
  }

  .user-info {
    flex: 1;
    min-width: 0;
  }

  .top-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.25rem;
  }

  .name {
    font-weight: 600;
    color: var(--text);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .time {
    font-size: 0.75rem;
    color: var(--text-muted);
  }

  .last-msg {
    font-size: 0.8125rem;
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    display: block;
  }

  .chat-area {
    flex: 1;
    display: flex;
    flex-direction: column;
    background: var(--surface);
  }

  .chat-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    gap: 1rem;
    background: var(--surface);
  }

  .chat-header h3 {
    margin: 0;
    font-size: 1rem;
    color: var(--text);
  }

  .chat-header .email {
    font-size: 0.8125rem;
    color: var(--text-muted);
  }

  .messages {
    flex: 1;
    overflow-y: auto;
    padding: 2rem;
    display: flex;
    flex-direction: column;
    gap: 1rem;
    background: var(--bg);
  }

  .message {
    display: flex;
    flex-direction: column;
    max-width: 70%;
  }

  .message.user {
    align-self: flex-start;
  }

  .message.admin {
    align-self: flex-end;
    align-items: flex-end;
  }

  .bubble {
    padding: 0.875rem 1rem;
    border-radius: 1rem;
    box-shadow: var(--shadow-sm);
  }

  .message.user .bubble {
    background: var(--surface);
    border: 1px solid var(--border);
    border-bottom-left-radius: 4px;
  }

  .message.admin .bubble {
    background: var(--primary);
    color: white;
    border-bottom-right-radius: 4px;
  }

  .bubble p {
    margin: 0;
    line-height: 1.5;
    font-size: 0.875rem;
  }

  .bubble img {
    max-width: 100%;
    border-radius: 0.5rem;
    margin-bottom: 0.5rem;
  }

  .msg-time {
    font-size: 0.6875rem;
    color: var(--text-muted);
    margin-top: 0.25rem;
    padding: 0 0.5rem;
  }

  .input-area {
    padding: 1.25rem 1.5rem;
    border-top: 1px solid var(--border);
    display: flex;
    gap: 0.75rem;
    background: var(--surface);
  }

  .input-area input {
    flex: 1;
    padding: 0.75rem 1.25rem;
    border-radius: 99px;
    border: 1.5px solid var(--border);
    background: var(--bg);
    outline: none;
    transition: all 0.2s;
    font-size: 0.875rem;
  }

  .input-area input:focus {
    border-color: var(--primary-accent);
    background: var(--surface);
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
  }

  .input-area button {
    padding: 0.75rem 1.5rem;
    border-radius: 99px;
    background: var(--primary);
    color: white;
    border: none;
    font-weight: 600;
    font-size: 0.8125rem;
    cursor: pointer;
    transition: all 0.2s;
  }

  .input-area button:hover:not(:disabled) {
    background: #1E293B;
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(15, 23, 42, 0.2);
  }

  .input-area button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .no-selection {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: var(--text-muted);
  }

  .no-selection svg {
    margin-bottom: 1rem;
    opacity: 0.3;
    color: var(--text-muted);
  }

  .no-selection h3 {
    margin: 0 0 0.5rem 0;
    color: var(--text-secondary);
  }

  .no-selection p {
    margin: 0;
    font-size: 0.875rem;
  }

  .loading, .empty-state {
    padding: 2rem;
    text-align: center;
    color: var(--text-muted);
    font-size: 0.875rem;
  }
</style>
