<script>
  import { supabase } from '$lib/supabase';
  import { goto } from '$app/navigation';
  
  let { data } = $props();
  let plan = $derived(data.plan);
  let recipes = $derived(data.recipes);

  let loading = $state(false);
  let entry = $state({
    day_of_week: data.initialDay,
    meal_time: '08:00 AM',
    meal_category: 'Breakfast',
    recipe_id: '',
    week_number: data.initialWeek
  });

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const categories = ['Breakfast', 'Lunch', 'Snack', 'Dinner'];

  async function handleSubmit(e) {
    e.preventDefault();
    loading = true;
    try {
      const { error } = await supabase
        .from('diet_plan_schedule')
        .insert([{
          ...entry,
          plan_id: plan.id
        }]);
      
      if (error) throw error;
      
      goto(`/admin/diets/${plan.id}`);
    } catch (err) {
      alert('Error scheduling meal: ' + err.message);
    } finally {
      loading = false;
    }
  }

  let selectedRecipe = $derived(recipes.find(r => r.id === entry.recipe_id));
</script>

<div class="page" style="animation: fadeIn 0.4s ease">
  <div class="page-head">
    <div class="head-left">
      <a href="/admin/diets/{plan?.id}" class="back-link">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
        Back to Planner
      </a>
      <h1>Schedule New Meal</h1>
      <p>Adding to <strong>{plan?.name}</strong> • Week {entry.week_number}</p>
    </div>
  </div>

  <div class="creation-grid">
    <div class="main-card card">
      <form onsubmit={handleSubmit} id="meal-form">
        <div class="form-section">
          <h3>Timing & Placement</h3>
          <div class="row">
            <div class="group">
              <label>Day of Week</label>
              <select bind:value={entry.day_of_week}>
                {#each days as day, i}
                  <option value={i}>{day}</option>
                {/each}
              </select>
            </div>
            <div class="group">
              <label>Category</label>
              <select bind:value={entry.meal_category}>
                {#each categories as cat}
                  <option value={cat}>{cat}</option>
                {/each}
              </select>
            </div>
          </div>
          <div class="group">
            <label>Meal Time</label>
            <input type="text" bind:value={entry.meal_time} placeholder="e.g. 08:30 AM" required />
          </div>
        </div>

        <div class="form-section">
          <h3>Recipe Selection</h3>
          <div class="group">
            <label>Select from Library</label>
            <select bind:value={entry.recipe_id} required size="8" class="recipe-select">
              {#each recipes as recipe}
                <option value={recipe.id}>{recipe.name} ({recipe.calories} kcal)</option>
              {/each}
            </select>
          </div>
        </div>
      </form>
    </div>

    <div class="side-panel">
      {#if selectedRecipe}
        <div class="preview-card card">
          <div class="p-img">
            {#if selectedRecipe.image_url}
              <img src={selectedRecipe.image_url} alt={selectedRecipe.name} />
            {:else}
              <div class="img-ph">🥗</div>
            {/if}
          </div>
          <div class="p-content">
            <span class="p-cat">{selectedRecipe.category}</span>
            <h3>{selectedRecipe.name}</h3>
            <div class="p-stats">
              <div class="s-item">
                <span class="s-val">{selectedRecipe.calories}</span>
                <span class="s-lbl">kcal</span>
              </div>
              <div class="s-item">
                <span class="s-val">{selectedRecipe.protein_g}g</span>
                <span class="s-lbl">Protein</span>
              </div>
              <div class="s-item">
                <span class="s-val">{selectedRecipe.carbs_g}g</span>
                <span class="s-lbl">Carbs</span>
              </div>
            </div>
          </div>
        </div>
      {:else}
        <div class="empty-preview card">
          <div class="e-icon">🍽️</div>
          <p>Select a recipe to see details and nutritional impact.</p>
        </div>
      {/if}

      <div class="action-wrap">
        <button type="submit" form="meal-form" class="btn-primary" disabled={loading || !entry.recipe_id}>
          {loading ? 'Adding...' : 'Add to Schedule'}
        </button>
        <button type="button" class="btn-outline" onclick={() => history.back()}>Cancel</button>
      </div>
    </div>
  </div>
</div>

<style>
  .page { max-width: 1000px; margin: 0 auto; }
  
  .page-head { margin-bottom: 2.5rem; }
  .back-link { display: inline-flex; align-items: center; gap: 0.5rem; color: var(--text-muted); text-decoration: none; font-weight: 700; font-size: 0.8125rem; margin-bottom: 1rem; }
  .back-link:hover { color: var(--primary-accent); }
  
  h1 { font-size: 2rem; font-weight: 800; color: var(--text); margin-bottom: 0.25rem; }
  p { color: var(--text-muted); font-size: 0.875rem; }
  p strong { color: var(--text); }

  .creation-grid { display: grid; grid-template-columns: 1fr 320px; gap: 2rem; align-items: flex-start; }
  
  .card { background: white; border-radius: 24px; border: 1px solid var(--border); box-shadow: var(--shadow-sm); overflow: hidden; }
  
  .main-card { padding: 2.5rem; }
  .form-section { margin-bottom: 2.5rem; }
  .form-section h3 { font-size: 1rem; font-weight: 800; color: var(--text); margin-bottom: 1.25rem; padding-bottom: 0.75rem; border-bottom: 1px solid var(--border-light); }
  
  .row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
  .group { display: flex; flex-direction: column; gap: 0.5rem; margin-bottom: 1.5rem; }
  label { font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.05em; }
  
  input, select {
    padding: 0.875rem 1.125rem; border-radius: 14px;
    border: 1.5px solid var(--border); background: var(--bg);
    font-size: 0.9375rem; font-weight: 600; color: var(--text);
    outline: none; transition: all 0.2s;
  }
  input:focus, select:focus { border-color: var(--primary-accent); background: white; }

  .recipe-select { height: 300px; padding: 0.5rem; font-size: 0.875rem; }
  .recipe-select option { padding: 0.75rem 1rem; border-radius: 8px; margin-bottom: 2px; }
  .recipe-select option:checked { background: var(--primary-accent); color: white; }

  .side-panel { display: flex; flex-direction: column; gap: 1.5rem; position: sticky; top: 2rem; }
  
  .preview-card .p-img { height: 180px; background: var(--bg); }
  .preview-card .p-img img { width: 100%; height: 100%; object-fit: cover; }
  .img-ph { height: 100%; display: flex; align-items: center; justify-content: center; font-size: 3rem; opacity: 0.3; }
  
  .p-content { padding: 1.5rem; }
  .p-cat { font-size: 0.625rem; font-weight: 800; background: #EFF6FF; color: #3B82F6; padding: 2px 8px; border-radius: 4px; text-transform: uppercase; margin-bottom: 0.5rem; display: inline-block; }
  .p-content h3 { font-size: 1.125rem; font-weight: 800; color: var(--text); margin-bottom: 1rem; }
  
  .p-stats { display: flex; justify-content: space-between; border-top: 1px solid var(--border-light); padding-top: 1rem; }
  .s-item { text-align: center; }
  .s-val { display: block; font-size: 1rem; font-weight: 800; color: var(--text); }
  .s-lbl { font-size: 0.625rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; }

  .empty-preview { padding: 3rem 1.5rem; text-align: center; color: var(--text-muted); }
  .e-icon { font-size: 2.5rem; margin-bottom: 1rem; opacity: 0.3; }
  .empty-preview p { font-size: 0.8125rem; line-height: 1.5; font-weight: 600; }

  .action-wrap { display: flex; flex-direction: column; gap: 0.75rem; }
  .btn-primary { width: 100%; background: var(--primary-accent); color: white; border: none; padding: 1rem; border-radius: 14px; font-weight: 700; font-size: 0.9375rem; cursor: pointer; transition: all 0.2s; }
  .btn-primary:hover:not(:disabled) { background: var(--primary-accent-hover); transform: translateY(-1px); box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2); }
  .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
  .btn-outline { width: 100%; background: white; border: 1.5px solid var(--border); color: var(--text-secondary); padding: 1rem; border-radius: 14px; font-weight: 700; font-size: 0.9375rem; cursor: pointer; }
</style>
